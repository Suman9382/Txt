import os
from telegram import Update, InputFile
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext
from utils.txt_to_video import convert_txt_to_video
from utils.drm_protection import apply_drm
from config import TELEGRAM_TOKEN, SAVE_PATH

def start(update: Update, context: CallbackContext) -> None:
    update.message.reply_text(
        "Welcome to the TXT to Video bot! Here are your options:\n"
        "- Send a TXT file to convert it into a video.\n"
        "- Use `/settings` to customize options like duration, resolution, colors, and DRM."
    )

def settings(update: Update, context: CallbackContext) -> None:
    update.message.reply_text(
        "Available options:\n"
        "- `/duration <seconds>`: Set duration for each text line.\n"
        "- `/resolution <width>x<height>`: Set video resolution.\n"
        "- `/fontsize <size>`: Set font size.\n"
        "- `/colors <text_color>,<bg_color>`: Set text and background colors.\n"
        "- `/drm`: Enable DRM protection for the output video."
    )

def handle_txt_file(update: Update, context: CallbackContext) -> None:
    try:
        file = update.message.document
        if file.mime_type != 'text/plain':
            update.message.reply_text("Invalid file format. Please send a valid TXT file.")
            return

        update.message.reply_text("Processing your TXT file...")

        file_path = os.path.join(SAVE_PATH, file.file_name)
        file.download(file_path)

        args = context.args if context.args else []
        drm_enabled = "drm" in [arg.lower() for arg in args]
        duration = int(args[1]) if len(args) > 1 and args[0].lower() == "duration" else 5
        resolution = (1920, 1080)
        font_size = 24
        text_color, bg_color = "white", "black"
        output_format = "mp4"

        for arg in args:
            if "resolution" in arg.lower():
                resolution = tuple(map(int, arg.split()[1].split("x")))
            elif "fontsize" in arg.lower():
                font_size = int(arg.split()[1])
            elif "colors" in arg.lower():
                text_color, bg_color = arg.split()[1].split(",")

        video_path = convert_txt_to_video(
            txt_path=file_path,
            duration_per_line=duration,
            resolution=resolution,
            font_size=font_size,
            text_color=text_color,
            bg_color=bg_color,
            output_format=output_format,
        )

        if drm_enabled:
            video_path = apply_drm(video_path)

        with open(video_path, 'rb') as video_file:
            update.message.reply_video(video=InputFile(video_file))

        os.remove(file_path)
        os.remove(video_path)

    except Exception as e:
        update.message.reply_text(f"An error occurred: {str(e)}")

def main():
    updater = Updater(TELEGRAM_TOKEN)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("settings", settings))
    dp.add_handler(MessageHandler(Filters.document.mime_type("text/plain"), handle_txt_file))

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()