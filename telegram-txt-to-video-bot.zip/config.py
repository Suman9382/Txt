import os

TELEGRAM_TOKEN = "your-telegram-bot-token"
SAVE_PATH = os.path.join(os.getcwd(), "downloads")

if not os.path.exists(SAVE_PATH):
    os.makedirs(SAVE_PATH)