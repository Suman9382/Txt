import subprocess

def apply_drm(video_path: str) -> str:
    drm_video_path = video_path.replace(".mp4", "_drm.mp4")
    key_value = "00112233445566778899AABBCCDDEEFF"
    key_url = "https://example.com/drm-key"

    subprocess.run(
        [
            "ffmpeg",
            "-i", video_path,
            "-encryption_scheme", "cenc-aes-ctr",
            "-encryption_key", key_value,
            "-encryption_kid", key_value,
            "-encryption_key_url", key_url,
            "-y", drm_video_path,
        ],
        check=True,
    )

    return drm_video_path