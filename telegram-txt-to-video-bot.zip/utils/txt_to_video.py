from moviepy.editor import TextClip, concatenate_videoclips

def convert_txt_to_video(
    txt_path: str,
    duration_per_line: int = 5,
    resolution: tuple = (1920, 1080),
    font_size: int = 24,
    text_color: str = "white",
    bg_color: str = "black",
    output_format: str = "mp4",
) -> str:
    with open(txt_path, 'r') as file:
        lines = file.readlines()

    clips = []
    for i, line in enumerate(lines):
        if line.strip():
            clip = TextClip(
                txt=line.strip(),
                fontsize=font_size,
                color=text_color,
                bg_color=bg_color,
                size=resolution,
                duration=duration_per_line,
            )
            clips.append(clip)

        if i > 0 and i % 50 == 0:
            break

    final_clip = concatenate_videoclips(clips, method="compose")
    video_path = txt_path.replace(".txt", f".{output_format}")
    final_clip.write_videofile(video_path, fps=24, codec="libx264", preset="fast")

    return video_path