# Telegram TXT to Video Bot

## Features
- Converts TXT files to videos with customizable options (resolution, font size, colors, etc.).
- Supports DRM protection for videos.

## Setup
1. Clone the repository.
2. Install dependencies using `pip install -r requirements.txt`.
3. Set your bot token in `config.py`.
4. Run the bot using `python bot.py`.